# Set ROS domain ID
export ROS_DOMAIN_ID=4

# >>> conda initialize >>>
# !! Contents within this block are managed by 'conda init' !!
__conda_setup="$('/home/TP/tools/miniconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
    eval "$__conda_setup"
else
    if [ -f "/home/TP/tools/miniconda3/etc/profile.d/conda.sh" ]; then
        . "/home/TP/tools/miniconda3/etc/profile.d/conda.sh"
    else
        export PATH="/home/TP/tools/miniconda3/bin:$PATH"
    fi
fi
unset __conda_setup
# <<< conda initialize <<<


source /opt/ros/humble/setup.bash
conda activate E021_3_6
