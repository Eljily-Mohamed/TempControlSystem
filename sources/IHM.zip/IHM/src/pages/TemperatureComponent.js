import React, { useEffect, useState } from "react";
import LineChart from "../components/LineChart.js";
import socket from "../services/socketService.js";

const TemperatureComponent = () => {
  const [realTimeData, setRealTimeData] = useState([]);
  const [powerData, setPowerData] = useState([]);
  const [temperatureSetpoint, setTemperatureSetpoint] = useState(20);
  const [dutyCycle, setDutyCycle] = useState(90); 
  const [tensionMesure, setTensionMesure] = useState(0); 
  const [current, setCurrent] = useState(0);
  const [hasConnection, setHasConnection] = useState(true);
  const [isAcquisitionActive, setIsAcquisitionActive] = useState(false);

  useEffect(() => {
    const fetchData = (data) => {
      try {
        //console.log("Données reçues :", data);
  
        // Si le message commence par une clé suivie d'une valeur (par exemple "T:", "P:", "D:", "C:", "V:")
        const [key, value] = data.split(":");
        const numericValue = parseFloat(value);
  
        if (isNaN(numericValue)) {
          console.warn("Valeur non numérique reçue :", value);
          return; // Ignore les valeurs non numériques
        }
  
        switch (key) {
          case "T": // Température
            console.log("Température extraite :", numericValue);
            setRealTimeData((prevData) => [...prevData, numericValue]);
            break;
          case "P": // Puissance
            console.log("Puissance extraite :", numericValue);
            setPowerData((prevData) => [...prevData, numericValue]);
            break;
          case "D": // Cycle de travail
            console.log("Cycle de travail extrait :", numericValue);
            setDutyCycle(numericValue);
            break;
          case "C": // Courant
            console.log("Courant extrait :", numericValue);
            setCurrent(numericValue);
            break;
          case "V": // Tension
            console.log("Tension extraite :", numericValue);
            setTensionMesure(numericValue);
            break;
          default:
            console.warn(`Clé inconnue reçue: ${key}`);
        }
  
        // Si la connexion était perdue, la rétablir
        if (!hasConnection) {
          setHasConnection(true);
        }
      } catch (error) {
        console.error("Erreur lors de l'analyse des données reçues :", error);
      }
    };
  
    const handleDisconnect = () => {
      setHasConnection(false);
    };
  
    if (socket) {
      socket.on("serialData", fetchData);
      socket.on("disconnect", handleDisconnect);
    }
  
    // Nettoyage des écouteurs lorsque le composant est démonté ou les dépendances changent
    // return () => {
    //   if (socket) {
    //     socket.off("serialData", fetchData);
    //     socket.off("disconnect", handleDisconnect);
    //   }
    // };
  }, [hasConnection, realTimeData, socket]);
  

  const sendTemperatureSetpoint = () => {
    socket.emit("message", `${temperatureSetpoint}e`);
  };

  const increaseSetpoint = () => {
    setTemperatureSetpoint((prev) => {
      const newSetpoint = prev + 1;
      socket.emit("message", `${newSetpoint}e`);
      return newSetpoint;
    });
  };

  const decreaseSetpoint = () => {
    setTemperatureSetpoint((prev) => {
      const newSetpoint = prev - 1;
      socket.emit("message", `${newSetpoint}e`);
      return newSetpoint;
    });
  };

  const toggleAcquisition = () => {
    if (isAcquisitionActive) {
      console.log("Acquisition arrêtée.");
    } else {
      console.log("Acquisition démarrée.");
    }
    setIsAcquisitionActive(!isAcquisitionActive);
  };

  return (
    <div className="ml-[200px]">
      <div className="flex items-center mb-4">
        <label className="text-lg font-semibold">Point de consigne de température :</label>
        <div className="flex items-center ml-4">
          <button
            onClick={decreaseSetpoint}
            className="bg-red-500 text-white px-6 py-3 text-lg font-bold rounded-lg mr-4"
          >
            -
          </button>
          <span className="text-xl font-bold">{temperatureSetpoint}°C</span>
          <button
            onClick={increaseSetpoint}
            className="bg-green-500 text-white px-6 py-3 text-lg font-bold rounded-lg ml-4"
          >
            +
          </button>
        </div>

        <button
          onClick={toggleAcquisition}
          className={`ml-6 px-6 py-3 text-lg font-bold rounded-lg text-white ${
            isAcquisitionActive ? "bg-red-600" : "bg-green-600"
          }`}
        >
          {isAcquisitionActive ? "Arrêter l'acquisition" : "Démarrer l'acquisition"}
        </button>
      </div>

      <div className="mt-4 p-4 border rounded-lg bg-gray-100">
        <h3 className="text-lg font-bold mb-2"></h3>
        <p className="text-lg">Tension : <span className="font-bold">{tensionMesure} V</span></p>
        <p className="text-lg mb-1">Duty Cycle : <span className="font-bold">{dutyCycle}%</span></p>
        <p className="text-lg">Courant : <span className="font-bold">{current} A</span></p>
      </div>

      {hasConnection && (
        <>
          <div className="mt-4">
            <p className="text-lg font-semibold mb-2">Température au fil du temps</p>
            <div className="w-full h-[250px]"> {/* Hauteur réduite */}
              <LineChart
                label="Température"
                data={realTimeData}
                unit="Celsius"
                color="rgba(255, 99, 132, 1)"
              />
            </div>
          </div>

          <div className="mt-4">
            <p className="text-lg font-semibold mb-2">Variation de puissance</p>
            <div className="w-full h-[250px]"> {/* Hauteur réduite */}
              <LineChart
                label="Puissance"
                data={powerData}
                unit="Watts"
                color="rgba(54, 162, 235, 1)"
              />
            </div>
          </div>

        </>
      )}
    </div>
  );
};

export default TemperatureComponent;
