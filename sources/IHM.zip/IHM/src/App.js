// App.js
import React, { useState, useEffect } from "react";
import { Sun, Settings } from "lucide-react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sidebar, { SidebarItem } from "./components/Sidebar.js";
import TemperatureComponent from "./pages/TemperatureComponent.js";
import socket from "./services/socketService.js";

function App() {
  const [activeComponent, setActiveComponent] = useState("Temperature");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [fanMode, setFanMode] = useState("OFF"); // Default to OFF

  const ChangeActive = (text) => {
    console.log(text);
    setActiveComponent(text);
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleFanModeChange = (e) => {
    const selectedMode = e.target.value;
    setFanMode(selectedMode);
    socket.emit("message", selectedMode === "ON" ? "fan ON" : "fan OFF"); // Send the fan mode command
    toast.success(`Mode ventilateur changé : ${selectedMode}`); // Show success message
  };

  useEffect(() => {
    console.log("je suis la");

    const handleConnect = () => {
      console.log("Socket connected");
      toast.info("Connected to server");
    };

    const handleDisconnect = () => {
      console.log("Socket disconnected");
      toast.error("Disconnected from server");
    };

    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);

    // Cleanup on component unmount
    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
    };
  }, []);

  return (
    <>
      <div className="flex bg-gray-50 min-h-screen">
        <Sidebar>
          <SidebarItem
            icon={<Sun size={20} />}
            text="Temperature"
            active={activeComponent === "Temperature"}
            onClick={ChangeActive}
          />
          <hr className="my-3" />
          <div className="relative">
            <SidebarItem
              icon={<Settings size={20} />}
              text="Settings"
              onClick={toggleDropdown}
              className={`cursor-pointer flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-md transition duration-150 ease-in-out ${isDropdownOpen ? 'bg-gray-200' : ''}`}
            />
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-20">
                <div className="py-2 text-center text-sm font-semibold text-gray-800 border-b">
                  Asservissement de Ventilateur
                </div>
                <div className="py-1 px-2 flex flex-col items-center">
                  <label className="inline-flex items-center mb-2">
                    <input
                      type="radio"
                      value="OFF"
                      checked={fanMode === "OFF"}
                      onChange={handleFanModeChange}
                      className="form-radio h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    />
                    <span className="ml-2 text-gray-700">OFF</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      value="ON"
                      checked={fanMode === "ON"}
                      onChange={handleFanModeChange}
                      className="form-radio h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    />
                    <span className="ml-2 text-gray-700">ON</span>
                  </label>
                </div>
              </div>
            )}
            <ToastContainer />
          </div>
        </Sidebar>
        <div className="w-5/6 p-5">
          {activeComponent === "Temperature" && <TemperatureComponent />}
        </div>
      </div>
    </>
  );
}

export default App;
