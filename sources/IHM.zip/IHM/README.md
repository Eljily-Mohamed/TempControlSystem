Getting Started

To set up and run this project, follow these simple steps:

Step 1: Install Dependencies

Run the following command to install all necessary dependencies:

       npm install

Step 2: Start Development Mode

After the installation, start the development mode with Electron using:

      npm run electron-dev

That's it! The application should now be running.


