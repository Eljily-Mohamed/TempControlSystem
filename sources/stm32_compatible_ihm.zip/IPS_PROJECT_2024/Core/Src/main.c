
#include "main.h"
#include <stdio.h>
#include <math.h>

// Définitions des constantes
#define RING_BUF_SIZE 60 // Taille du buffer circulaire
#define T_CIBLE 40.0     // Température cible
#define KP 10.17         // Gain proportionnel pour le contrôle PID
#define KI 0.147         // Gain intégral pour le contrôle PID
#define KD 0             // Gain dérivé pour le contrôle PID

typedef volatile struct RingBuffer {
	char buf[RING_BUF_SIZE];
	int  i_push;		/* pointeur (index) d'écriture */
	int  i_pop;		/* pointeur (index) de lecture */
} RingBuffer;

static RingBuffer rx_buf = {
	.i_push=0,
	.i_pop=0
};


ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
TIM_HandleTypeDef htim2;
UART_HandleTypeDef huart2;

//Buffers
char txBufSend[10];    //envoi des données
char txBufReceive[10];    //reception des données


void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
int put_char(char);
void term_printf_stlink(const char* fmt, ...);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);


// Variables globales pour les calculs
volatile int ihm = 20;     // Variable de contrôle utilisateur
double R0 = 47;            // Résistance nominale
double T0 = 298;           // Température nominale en Kelvin
double beta = 4450;        // Constante de la thermistance

// Fonction pour calculer une résistance à partir d'un Pont de Wheatstone
// Vs : tension mesurée au point central du pont
// Vin : tension d'entrée appliquée au pont
// R1, R2, R3 : résistances fixes du pont
// R4 : résistance inconnue à calculer (résistance Thr)

double calculateRxEqualR(double Vs ) {
    // Vérification des entrées pour éviter les divisions par zéro
	double Vin= 5;
	double R= 68;
	// Vs=1.5;
    // Calcul intermédiaire : Vin/Vout
    double fraction = Vs / Vin + 0.5;
    double R4 = (R / fraction) - R;
    return R4;

}

// Conversion d'une valeur brute en tension
double calcul_tension(double volt)
{
  return volt * (3.3f / 4095.0);
}

// Calcul de la température à partir de la résistance (Thr)
double calculate_temperature(double R) {
    double T = 1 / ((1 / T0) + (1 / beta) * log(R / R0));
    return T-273.15;
}

// Conversion de la tension en courant
double calcul_courant(float courant)
{
	return (-(courant-(2.64*1200))/(0.185*1200));
}

// Calcul de la résistance(plaque shuff) en fonction de la température
double calcule_R(double T) {
    double T_kelvin = T + 273.15;
    return 0.00171295 * pow(T_kelvin, 3) - 1.54969842 * pow(T_kelvin, 2) + 468.13566846 * T_kelvin - 47202.84870824;
}




char msg[100];


int main(void)
{
  HAL_Init();
  HAL_MspInit();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

  static double integrale = 0;
  double erreur = 0.0,U_commande = 0.0,ui=0.0,temp=0.0,Ucible=0.0,courant=0.0,tension_now=0.0;
  int duty=0;
  float puissance;
  float Puissance_max = pow(24,2)/calcule_R(20);

  while(1){

		HAL_ADC_Start(&hadc1);
		HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
		ADC_Select_CH0();

		unsigned long adc_value0 = HAL_ADC_GetValue(&hadc1);
		tension_now = (adc_value0 *3.3f) /4095.0f;


		double R = calculateRxEqualR(tension_now);

		//sprintf(msg,"res:%.2f\r\n",R);
		//HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

		HAL_ADC_Start(&hadc1);
		HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
		ADC_Select_CH1();


		unsigned long adc_value1 = HAL_ADC_GetValue(&hadc1);

		float Ucourant=(float)adc_value1;
		courant = calcul_courant(Ucourant);

		//sprintf(msg,"courant : %f A\r\n",courant);


		temp = calculate_temperature(R);
		//erreur=T_CIBLE - temp; // pour test sans IHM
		erreur=ihm - temp;

		integrale = integrale + erreur*0.1;
		U_commande = (KP*2) * erreur + (2*KI) * integrale;


		// Limiter la tension à 0-24 V
		if (U_commande > 24) {
		U_commande = 24;
		integrale -= (erreur * 0.1);
		} else if (U_commande < 0) {
		U_commande = 0;
		integrale -= (erreur * 0.1);
		}


		puissance=pow(U_commande,2)/calcule_R(temp);
		duty = (int)roundf((puissance / Puissance_max) * 100);
		htim2.Instance->CCR1=duty;

		//sprintf(msg,"erreur:%.2f | U_commande:%.2f | P:%.2fW | Puissance_max:%.2f\r\n",erreur, U_commande, puissance, Puissance_max);
		//HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
		// Envoyer la tension (V) et le courant (C)
		sprintf(msg, "V:%.2f \r\n", tension_now);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

		sprintf(msg, "C:%.2f \r\n", courant);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

		// Envoyer la température (T) et le cycle de travail (D)
		sprintf(msg, "T:%.2f \r\n", temp);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

		sprintf(msg, "D:%d \r\n", duty);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

		// Envoyer la puissance (P)
		sprintf(msg, "P:%.2f \r\n", puissance);
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

		HAL_Delay(500);
  }
}


/**

  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};


  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);


  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }


  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

void ADC_Select_CH0 (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	  */
	  sConfig.Channel = ADC_CHANNEL_1;
	  sConfig.Rank = 1;
	  //sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}

void ADC_Select_CH1 (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	  */
	  sConfig.Channel = ADC_CHANNEL_0;
	  sConfig.Rank = 1;
	  //sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}



static void MX_TIM2_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 1599;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 200;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_TIM_MspPostInit(&htim2);

}


static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_UART_Receive_IT(&huart2, (uint8_t *)txBufReceive, 1);
}


static void MX_GPIO_Init(void)
{


	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* Configure PA0 and PA1 as analog input for ADC */
	__HAL_RCC_GPIOA_CLK_ENABLE();  // Activer l'horloge pour GPIOA

	GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;  // Mode analogique pour les entrées ADC
	GPIO_InitStruct.Pull = GPIO_NOPULL;      // Pas de résistance de pull-up ou pull-down
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}


int put_char(char ch)
{
	HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);
}


int putchar_stlink(char ch)
{
	HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);
	return 0;
}

//=================================================================
//	Helper Functions and Buffer Management
//=================================================================

// Add data to the buffer
static void add_to_buffer(char data) {
    // Check if buffer is not full
    if ((rx_buf.i_push + 1) % RING_BUF_SIZE != rx_buf.i_pop) {
        // Add character to the buffer
        rx_buf.buf[rx_buf.i_push] = data;
        // Increment write index
        rx_buf.i_push = (rx_buf.i_push + 1) % RING_BUF_SIZE;
    }
}

// Clear the buffer
static void clear_buffer() {
    // Reset both read and write indices
    rx_buf.i_push = 0;
    rx_buf.i_pop = 0;
}

void put_string_stlink(char* s)
{
	while(*s != '\0')
	{
		putchar_stlink(*s);
		s++;
	}
}

void term_printf_stlink(const char* fmt, ...)
{
	va_list        ap;
	char          *p;
	char           ch;
	unsigned long  ul;
	unsigned long long ull;
	unsigned long  size;
	unsigned int   sp;
	char           s[34];
	int 		 first=0;


	va_start(ap, fmt);
	while (*fmt != '\0') {
		if (*fmt =='%') {
			size=0; sp=1;
			if (*++fmt=='0') {fmt++; sp=0;}	// parse %04d --> sp=0
			ch=*fmt;
			if ((ch>'0') && (ch<='9')) {	// parse %4d --> size=4
				char tmp[10];
				int i=0;
				while ((ch>='0') && (ch<='9')) {
					tmp[i++]=ch;
					ch=*++fmt;
				}
				tmp[i]='\0';
				size=str2num(tmp,10);
			}
			switch (ch) {
				case '%':
					 putchar_stlink('%');
					break;
				case 'c':
					ch = va_arg(ap, int);
					putchar_stlink(ch);
					break;
				case 's':
					p = va_arg(ap, char *);
					put_string_stlink(p);
					break;
				case 'd':
					ul = va_arg(ap, long);
					if ((long)ul < 0) {
						putchar_stlink('-');
						ul = -(long)ul;
						//size--;
					}
					num2str(s, ul, 10, size, sp);
					put_string_stlink(s);
					break;
				case 'u':
					ul = va_arg(ap, unsigned int);
					num2str(s, ul, 10, size, sp);
					put_string_stlink(s);
					break;
				case 'o':
					ul = va_arg(ap, unsigned int);
					num2str(s, ul, 8, size, sp);
					put_string_stlink(s);
					break;
				case 'p':
					putchar_stlink('0');
					putchar_stlink('x');
					ul = va_arg(ap, unsigned int);
					num2str(s, ul, 16, size, sp);
					put_string_stlink(s);
					break;
				case 'x':
					ul = va_arg(ap, unsigned int);
					num2str(s, ul, 16, size, sp);
					put_string_stlink(s);
					break;
				case 'f':
					if(first==0){ ull = va_arg(ap, long long unsigned int); first = 1;}
					ull = va_arg(ap, long long unsigned int);
					int sign = ( ull & 0x80000000 ) >> 31;
					int m = (ull & 0x000FFFFF) ; // should be 0x007FFFFF
					float mf = (float)m ;
					mf = mf / pow(2.0,20.0);
					mf = mf + 1.0;
					int e = ( ull & 0x78000000 ) >> 23 ; // should be int e = ( ul & 0x7F800000 ) >> 23;
					e = e | (( ull & 0x000F00000 ) >> 20);
					e = e - 127;
					float f = mf*myPow(2.0,e);
					if(sign==1){ put_char('-'); }
					float2str((char*)s, f, 5);
					put_string_stlink((char*)s);
					break;
				default:
					putchar_stlink(*fmt);
			}
		} else putchar_stlink(*fmt);
		fmt++;
	}
	va_end(ap);
}

//fonction callback de réception de données sur le port série
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

	HAL_UART_Receive_IT(&huart2, (uint8_t *)txBufReceive, 1);
	char car_received= (char)txBufReceive[0];
	//char 'e' mean end of commande
	if(car_received == 'e'){
		rx_buf.buf[rx_buf.i_push] = '\0';
		ihm = atoi(rx_buf.buf);
		clear_buffer();
	}else{
		add_to_buffer(car_received);
	}
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
